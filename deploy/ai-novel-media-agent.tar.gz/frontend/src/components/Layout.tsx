import { Link, useLocation } from 'react-router-dom'

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation()

  return (
    <div className="layout">
      <div className="sidebar">
        <div className="logo">AI 创作平台</div>
        <Link to="/dashboard" className={`menu-item ${location.pathname === '/dashboard' ? 'active' : ''}`}>
          📊 仪表盘
        </Link>
        <Link to="/create" className={`menu-item ${location.pathname === '/create' ? 'active' : ''}`}>
          ➕ 创建任务
        </Link>
        <Link to="/tasks" className={`menu-item ${location.pathname === '/tasks' ? 'active' : ''}`}>
          📋 我的任务
        </Link>
        <Link to="/novels" className={`menu-item ${location.pathname === '/novels' ? 'active' : ''}`}>
          📖 小说作品
        </Link>
      </div>
      <div className="main">{children}</div>
    </div>
  )
}
