import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Layout from '../components/Layout'

export default function Dashboard() {
  const [stats, setStats] = useState({ tasks: 0, novels: 0, balance: 0 })

  useEffect(() => {
    fetch('/api/dashboard', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
      .then(res => res.json())
      .then(data => setStats(data))
      .catch(err => console.error(err))
  }, [])

  return (
    <Layout>
      <div className="topbar">
        <h1>仪表盘</h1>
      </div>
      <div className="stats">
        <div className="stat-card">
          <div className="label">进行中任务</div>
          <div className="value">{stats.tasks}</div>
        </div>
        <div className="stat-card">
          <div className="label">已完成作品</div>
          <div className="value">{stats.novels}</div>
        </div>
        <div className="stat-card">
          <div className="label">账户余额</div>
          <div className="value">¥{stats.balance}</div>
        </div>
      </div>
      <div className="card">
        <h2>快速开始</h2>
        <Link to="/create" className="btn btn-primary">创建新任务</Link>
      </div>
    </Layout>
  )
}
