import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'

export default function CreateTask() {
  const [taskType, setTaskType] = useState('novel_only')
  const [lengthType, setLengthType] = useState('short')
  const [genre, setGenre] = useState('male')
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ task_type: taskType, novel_config: { length_type: lengthType, genre } })
      })
      if (res.ok) {
        navigate('/tasks')
      }
    } catch (err) {
      console.error('Create task failed:', err)
    }
  }

  return (
    <Layout>
      <div className="topbar">
        <h1>创建任务</h1>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="card">
          <h2>选择创作方式</h2>
          <div className="form-group">
            <label>任务类型</label>
            <select value={taskType} onChange={e => setTaskType(e.target.value)}>
              <option value="novel_only">只生成小说</option>
              <option value="novel_video">小说 + 视频</option>
              <option value="external_video">外部小说 → 视频</option>
              <option value="news_video">资讯 → 视频</option>
            </select>
          </div>
        </div>
        <div className="card">
          <h2>小说配置</h2>
          <div className="form-group">
            <label>篇幅</label>
            <select value={lengthType} onChange={e => setLengthType(e.target.value)}>
              <option value="micro">微小说 (1-5千字)</option>
              <option value="short">短篇 (0.5-3万字)</option>
              <option value="medium">中篇 (3-10万字)</option>
              <option value="long">长篇 (10-50万字)</option>
              <option value="ultra">超长篇 (50万+)</option>
            </select>
          </div>
          <div className="form-group">
            <label>题材</label>
            <select value={genre} onChange={e => setGenre(e.target.value)}>
              <option value="children">儿童故事</option>
              <option value="male">男频</option>
              <option value="female">女频</option>
            </select>
          </div>
        </div>
        <button type="submit" className="btn btn-primary">开始创建</button>
      </form>
    </Layout>
  )
}
