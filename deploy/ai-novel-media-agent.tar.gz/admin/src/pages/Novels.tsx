export default function Novels() {
  return (
    <div className="page">
      <h1 className="page-title">小说作品管理</h1>

      <div className="card">
        <div className="toolbar">
          <div>
            <input type="text" placeholder="搜索小说标题..." />
            <button className="btn btn-primary" style={{ marginLeft: '8px' }}>搜索</button>
          </div>
          <div>
            <select>
              <option>全部分类</option>
              <option>儿童</option>
              <option>男频</option>
              <option>女频</option>
            </select>
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>标题</th>
              <th>作者</th>
              <th>分类</th>
              <th>字数</th>
              <th>广场</th>
              <th>评分</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>N-001</td>
              <td>《龙族传说》</td>
              <td>creator_top</td>
              <td>玄幻·长篇</td>
              <td>32万</td>
              <td><span className="badge badge-green">已发布</span></td>
              <td>4.5</td>
              <td>
                <button className="btn btn-sm btn-outline">查看</button>{' '}
                <button className="btn btn-sm btn-danger">下架</button>
              </td>
            </tr>
            <tr>
              <td>N-002</td>
              <td>《霸总的秘密》</td>
              <td>novel_fan</td>
              <td>霸总·短篇</td>
              <td>2.8万</td>
              <td><span className="badge badge-green">已发布</span></td>
              <td>4.2</td>
              <td>
                <button className="btn btn-sm btn-outline">查看</button>{' '}
                <button className="btn btn-sm btn-danger">下架</button>
              </td>
            </tr>
            <tr>
              <td>N-003</td>
              <td>《小兔冒险》</td>
              <td>creator_top</td>
              <td>儿童·微小说</td>
              <td>3千</td>
              <td><span className="badge badge-gray">未发布</span></td>
              <td>-</td>
              <td>
                <button className="btn btn-sm btn-outline">查看</button>{' '}
                <button className="btn btn-sm btn-danger">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
