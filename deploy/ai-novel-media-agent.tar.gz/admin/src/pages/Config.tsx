import './Config.css'

export default function Config() {
  return (
    <div className="page">
      <h1 className="page-title">系统配置</h1>

      <div className="card">
        <h2>套餐定价</h2>
        <table className="table">
          <thead>
            <tr>
              <th>套餐</th>
              <th>小说单价(千字)</th>
              <th>视频单价(秒)</th>
              <th>API限额</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>基础版</td>
              <td>¥0.05</td>
              <td>-</td>
              <td>-</td>
              <td>
                <button className="btn btn-sm btn-outline">编辑</button>
              </td>
            </tr>
            <tr>
              <td>进阶版</td>
              <td>¥0.08</td>
              <td>¥0.15</td>
              <td>-</td>
              <td>
                <button className="btn btn-sm btn-outline">编辑</button>
              </td>
            </tr>
            <tr>
              <td>专业版</td>
              <td>¥0.10</td>
              <td>¥0.20</td>
              <td>1000/天</td>
              <td>
                <button className="btn btn-sm btn-outline">编辑</button>
              </td>
            </tr>
            <tr>
              <td>企业版</td>
              <td>定制</td>
              <td>定制</td>
              <td>无限</td>
              <td>
                <button className="btn btn-sm btn-outline">编辑</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>系统参数</h2>
        <div className="config-form">
          <label>
            计费倍率范围
            <div className="range-input">
              <input type="number" defaultValue="1.1" step="0.01" /> ~
              <input type="number" defaultValue="1.2" step="0.01" />
            </div>
          </label>
          <label>
            最大并发任务数
            <input type="number" defaultValue="20" />
          </label>
          <label>
            发布模式
            <select>
              <option>mock (模拟)</option>
              <option>production (生产)</option>
            </select>
          </label>
          <button className="btn btn-primary">保存配置</button>
        </div>
      </div>
    </div>
  )
}
