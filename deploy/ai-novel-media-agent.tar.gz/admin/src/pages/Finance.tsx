export default function Finance() {
  return (
    <div className="page">
      <h1 className="page-title">财务报表</h1>

      <div className="stats">
        <div className="stat-card">
          <div className="label">本月总收入</div>
          <div className="value" style={{ color: '#22c55e' }}>¥128,450</div>
        </div>
        <div className="stat-card">
          <div className="label">本月 API 成本</div>
          <div className="value" style={{ color: '#ef4444' }}>¥98,200</div>
        </div>
        <div className="stat-card">
          <div className="label">本月毛利</div>
          <div className="value" style={{ color: '#6366f1' }}>¥30,250</div>
        </div>
        <div className="stat-card">
          <div className="label">毛利率</div>
          <div className="value">23.5%</div>
        </div>
      </div>

      <div className="card">
        <h2>收入 vs 成本趋势</h2>
        <div className="chart-placeholder">📈 双折线图：收入(绿) / API成本(红)</div>
      </div>

      <div className="grid-half">
        <div className="card">
          <h2>收入来源分布</h2>
          <div className="chart-placeholder">🍩 饼图：小说/视频/充值</div>
        </div>
        <div className="card">
          <h2>套餐收入分布</h2>
          <div className="chart-placeholder">📊 柱状图：基础/进阶/专业/企业</div>
        </div>
      </div>
    </div>
  )
}
