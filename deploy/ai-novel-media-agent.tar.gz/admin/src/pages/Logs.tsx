export default function Logs() {
  return (
    <div className="page">
      <h1 className="page-title">系统日志</h1>

      <div className="card">
        <div className="toolbar">
          <div>
            <select>
              <option>全部级别</option>
              <option>ERROR</option>
              <option>WARN</option>
              <option>INFO</option>
            </select>
            <input type="text" placeholder="搜索关键词..." style={{ marginLeft: '8px' }} />
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th>时间</th>
              <th>级别</th>
              <th>模块</th>
              <th>消息</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>13:05:22</td>
              <td><span className="badge badge-red">ERROR</span></td>
              <td>publisher</td>
              <td>番茄小说发布失败: 401 Token过期 (user: novel_fan)</td>
            </tr>
            <tr>
              <td>13:04:15</td>
              <td><span className="badge badge-yellow">WARN</span></td>
              <td>billing</td>
              <td>用户 user_xyz 余额不足, 任务 T-090 暂停</td>
            </tr>
            <tr>
              <td>13:03:48</td>
              <td><span className="badge badge-green">INFO</span></td>
              <td>pipeline</td>
              <td>任务 T-089 WriterAgent 完成第12章</td>
            </tr>
            <tr>
              <td>13:02:30</td>
              <td><span className="badge badge-green">INFO</span></td>
              <td>auth</td>
              <td>用户 user_1234 注册成功</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
