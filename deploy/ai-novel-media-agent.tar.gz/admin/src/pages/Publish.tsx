export default function Publish() {
  return (
    <div className="page">
      <h1 className="page-title">发布管理</h1>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>内容</th>
              <th>平台</th>
              <th>用户</th>
              <th>状态</th>
              <th>时间</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>P-101</td>
              <td>龙族传说·EP01</td>
              <td>抖音</td>
              <td>creator_top</td>
              <td><span className="badge badge-green">成功</span></td>
              <td>2h前</td>
              <td>
                <button className="btn btn-sm btn-outline">详情</button>
              </td>
            </tr>
            <tr>
              <td>P-100</td>
              <td>AI峰会速览</td>
              <td>小红书</td>
              <td>novel_fan</td>
              <td><span className="badge badge-yellow">审核中</span></td>
              <td>3h前</td>
              <td>
                <button className="btn btn-sm btn-outline">详情</button>
              </td>
            </tr>
            <tr>
              <td>P-099</td>
              <td>《霸总的秘密》</td>
              <td>番茄小说</td>
              <td>novel_fan</td>
              <td><span className="badge badge-red">失败</span></td>
              <td>5h前</td>
              <td>
                <button className="btn btn-sm btn-primary">重试</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
