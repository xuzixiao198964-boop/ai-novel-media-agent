export default function ApiKeys() {
  return (
    <div className="page">
      <h1 className="page-title">API Key 管理</h1>

      <div className="card">
        <div className="toolbar">
          <div>
            <input type="text" placeholder="搜索 Key / 用户..." />
            <button className="btn btn-primary" style={{ marginLeft: '8px' }}>搜索</button>
          </div>
          <div>
            <button className="btn btn-primary">+ 创建 Key</button>
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th>Key ID</th>
              <th>用户</th>
              <th>名称</th>
              <th>权限</th>
              <th>调用次数</th>
              <th>限流</th>
              <th>状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>ak_001</td>
              <td>dev_api</td>
              <td>生产环境</td>
              <td>全部</td>
              <td>12,456</td>
              <td>100/min</td>
              <td><span className="badge badge-green">活跃</span></td>
              <td>
                <button className="btn btn-sm btn-danger">吊销</button>
              </td>
            </tr>
            <tr>
              <td>ak_002</td>
              <td>dev_api</td>
              <td>测试环境</td>
              <td>只读</td>
              <td>890</td>
              <td>30/min</td>
              <td><span className="badge badge-green">活跃</span></td>
              <td>
                <button className="btn btn-sm btn-danger">吊销</button>
              </td>
            </tr>
            <tr>
              <td>ak_003</td>
              <td>creator_top</td>
              <td>OpenClaw</td>
              <td>任务+查询</td>
              <td>234</td>
              <td>10/min</td>
              <td><span className="badge badge-green">活跃</span></td>
              <td>
                <button className="btn btn-sm btn-danger">吊销</button>
              </td>
            </tr>
            <tr>
              <td>ak_004</td>
              <td>bad_user</td>
              <td>已禁用</td>
              <td>-</td>
              <td>56</td>
              <td>-</td>
              <td><span className="badge badge-red">已吊销</span></td>
              <td>-</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
