import { useEffect, useState } from 'react'
import Layout from '../components/Layout'

export default function Users() {
  const [users, setUsers] = useState<any[]>([])

  useEffect(() => {
    fetch('/api/admin/users', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('admin_token')}` }
    })
      .then(res => res.json())
      .then(data => setUsers(data))
      .catch(err => console.error(err))
  }, [])

  return (
    <Layout>
      <div className="topbar">
        <h1>用户管理</h1>
      </div>
      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>用户名</th>
              <th>邮箱</th>
              <th>套餐</th>
              <th>余额</th>
              <th>状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td><span className="badge badge-blue">{user.package}</span></td>
                <td>¥{user.balance}</td>
                <td><span className={`badge badge-${user.status === 'active' ? 'green' : 'red'}`}>{user.status}</span></td>
                <td>
                  <button className="btn btn-sm btn-outline">查看</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
