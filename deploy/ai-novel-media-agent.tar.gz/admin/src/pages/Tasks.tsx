import { useEffect, useState } from 'react'
import Layout from '../components/Layout'

export default function Tasks() {
  const [tasks, setTasks] = useState<any[]>([])

  useEffect(() => {
    fetch('/api/admin/tasks', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('admin_token')}` }
    })
      .then(res => res.json())
      .then(data => setTasks(data))
      .catch(err => console.error(err))
  }, [])

  return (
    <Layout>
      <div className="topbar">
        <h1>任务监控</h1>
      </div>
      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>任务ID</th>
              <th>用户</th>
              <th>类型</th>
              <th>状态</th>
              <th>进度</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map(task => (
              <tr key={task.id}>
                <td>{task.id}</td>
                <td>{task.username}</td>
                <td>{task.type}</td>
                <td><span className={`badge badge-${task.status === 'running' ? 'green' : task.status === 'queued' ? 'yellow' : 'blue'}`}>{task.status}</span></td>
                <td>{task.progress}%</td>
                <td>
                  <button className="btn btn-sm btn-outline">详情</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
