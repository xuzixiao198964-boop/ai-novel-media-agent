import { useEffect, useState } from 'react'
import Layout from '../components/Layout'

export default function Dashboard() {
  const [stats, setStats] = useState({ users: 0, tasks: 0, revenue: 0, works: 0 })

  useEffect(() => {
    fetch('/api/admin/stats', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('admin_token')}` }
    })
      .then(res => res.json())
      .then(data => setStats(data))
      .catch(err => console.error(err))
  }, [])

  return (
    <Layout>
      <div className="topbar">
        <h1>数据概览</h1>
        <div>管理员: admin</div>
      </div>
      <div className="stats">
        <div className="stat-card">
          <div className="label">用户总数</div>
          <div className="value">{stats.users}</div>
        </div>
        <div className="stat-card">
          <div className="label">活跃任务</div>
          <div className="value">{stats.tasks}</div>
        </div>
        <div className="stat-card">
          <div className="label">今日收入</div>
          <div className="value" style={{color:'#22c55e'}}>¥{stats.revenue}</div>
        </div>
        <div className="stat-card">
          <div className="label">作品总数</div>
          <div className="value">{stats.works}</div>
        </div>
      </div>
    </Layout>
  )
}
