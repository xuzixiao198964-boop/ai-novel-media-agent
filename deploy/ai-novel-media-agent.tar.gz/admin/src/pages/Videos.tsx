export default function Videos() {
  return (
    <div className="page">
      <h1 className="page-title">视频作品管理</h1>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>标题</th>
              <th>作者</th>
              <th>类型</th>
              <th>时长</th>
              <th>集数</th>
              <th>状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>V-001</td>
              <td>龙族传说</td>
              <td>creator_top</td>
              <td>小说类</td>
              <td>36min</td>
              <td>12集</td>
              <td><span className="badge badge-green">已发布</span></td>
              <td>
                <button className="btn btn-sm btn-outline">查看</button>
              </td>
            </tr>
            <tr>
              <td>V-002</td>
              <td>AI峰会速览</td>
              <td>novel_fan</td>
              <td>资讯类</td>
              <td>2:30</td>
              <td>1</td>
              <td><span className="badge badge-blue">广场</span></td>
              <td>
                <button className="btn btn-sm btn-outline">查看</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
