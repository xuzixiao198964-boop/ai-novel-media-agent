import { NavLink } from 'react-router-dom'
import './Sidebar.css'

export default function Sidebar() {
  return (
    <div className="sidebar">
      <div className="logo">🛡️ 管理后台</div>
      <NavLink to="/dashboard" className="menu-item">📊 数据概览</NavLink>
      <NavLink to="/users" className="menu-item">👥 用户管理</NavLink>
      <NavLink to="/novels" className="menu-item">📖 小说管理</NavLink>
      <NavLink to="/videos" className="menu-item">🎬 视频管理</NavLink>
      <NavLink to="/tasks" className="menu-item">📋 任务监控</NavLink>
      <NavLink to="/apikeys" className="menu-item">🔑 API Key</NavLink>
      <NavLink to="/finance" className="menu-item">💰 财务报表</NavLink>
      <NavLink to="/publish" className="menu-item">📤 发布管理</NavLink>
      <NavLink to="/logs" className="menu-item">📝 系统日志</NavLink>
      <NavLink to="/config" className="menu-item">⚙️ 系统配置</NavLink>
    </div>
  )
}
