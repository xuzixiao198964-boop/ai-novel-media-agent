import './Topbar.css'

export default function Topbar() {
  return (
    <div className="topbar">
      <div></div>
      <div className="admin-info">
        管理员: admin | <a href="#logout">退出</a>
      </div>
    </div>
  )
}
