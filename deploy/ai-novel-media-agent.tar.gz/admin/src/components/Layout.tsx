import { Link, useLocation } from 'react-router-dom'

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation()

  return (
    <div className="layout">
      <div className="sidebar">
        <div className="logo">🛡️ 管理后台</div>
        <Link to="/dashboard" className={`menu-item ${location.pathname === '/dashboard' ? 'active' : ''}`}>
          📊 数据概览
        </Link>
        <Link to="/users" className={`menu-item ${location.pathname === '/users' ? 'active' : ''}`}>
          👥 用户管理
        </Link>
        <Link to="/tasks" className={`menu-item ${location.pathname === '/tasks' ? 'active' : ''}`}>
          📋 任务监控
        </Link>
      </div>
      <div className="main">{children}</div>
    </div>
  )
}
