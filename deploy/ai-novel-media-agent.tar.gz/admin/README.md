# Admin - 后台管理系统

React + TypeScript + Vite 实现的管理后台

## 启动方式

```bash
# 安装依赖
npm install

# 开发环境 (http://localhost:3001)
npm run dev

# 构建生产版本
npm run build
```

## 功能页面

- `/login` - 管理员登录
- `/dashboard` - 数据概览
- `/users` - 用户管理
- `/tasks` - 任务监控

## API 连接

所有 API 请求会自动代理到 `http://localhost:8000`

## 技术栈

- React 18
- TypeScript
- React Router
- Vite
