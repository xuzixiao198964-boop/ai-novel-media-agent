# -*- coding: utf-8 -*-
"""后台管理API路由"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func

from app.database import get_db
from app.models import User, Task, Novel, Video, Payment, APIKey
from app.core.deps import get_current_admin

router = APIRouter()


@router.get("/dashboard")
async def get_dashboard(
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """获取仪表盘数据"""
    # 用户总数
    user_count = await db.execute(select(func.count(User.id)))
    total_users = user_count.scalar()

    # 活跃任务数
    active_tasks = await db.execute(
        select(func.count(Task.id)).where(
            Task.status.in_(["queued", "preparing", "running", "auditing", "revising"])
        )
    )
    active_task_count = active_tasks.scalar()

    # 今日收入
    from datetime import datetime, timedelta
    today = datetime.utcnow().date()
    today_income = await db.execute(
        select(func.sum(Payment.amount)).where(
            Payment.status == "success",
            func.date(Payment.paid_at) == today
        )
    )
    income = today_income.scalar() or 0.0

    # 作品总数
    novel_count = await db.execute(select(func.count(Novel.id)))
    video_count = await db.execute(select(func.count(Video.id)))
    total_works = novel_count.scalar() + video_count.scalar()

    return {
        "total_users": total_users,
        "active_tasks": active_task_count,
        "today_income": income,
        "total_works": total_works
    }


@router.get("/users")
async def list_users(
    skip: int = 0,
    limit: int = 20,
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """获取用户列表"""
    result = await db.execute(
        select(User).order_by(desc(User.created_at)).offset(skip).limit(limit)
    )
    users = result.scalars().all()

    return {"total": len(users), "items": users}


@router.patch("/users/{user_id}/status")
async def update_user_status(
    user_id: int,
    is_active: bool,
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """更新用户状态（启用/禁用）"""
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不存在"
        )

    user.is_active = is_active
    await db.commit()

    return {"message": "用户状态已更新"}


@router.get("/tasks")
async def list_all_tasks(
    skip: int = 0,
    limit: int = 20,
    status_filter: str = None,
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """获取所有任务"""
    query = select(Task)

    if status_filter:
        query = query.where(Task.status == status_filter)

    query = query.order_by(desc(Task.created_at)).offset(skip).limit(limit)

    result = await db.execute(query)
    tasks = result.scalars().all()

    return {"total": len(tasks), "items": tasks}


@router.get("/api-keys")
async def list_api_keys(
    skip: int = 0,
    limit: int = 20,
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """获取所有API Key"""
    result = await db.execute(
        select(APIKey).order_by(desc(APIKey.created_at)).offset(skip).limit(limit)
    )
    api_keys = result.scalars().all()

    return {"total": len(api_keys), "items": api_keys}


@router.post("/api-keys")
async def create_api_key(
    user_id: int,
    name: str,
    permissions: list = None,
    rate_limit: int = 100,
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """创建API Key"""
    from app.core.security import generate_api_key, hash_api_key

    # 验证用户存在
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不存在"
        )

    # 生成API Key
    api_key = generate_api_key()
    key_hash = hash_api_key(api_key)

    # 创建记录
    api_key_record = APIKey(
        user_id=user_id,
        key_hash=key_hash,
        name=name,
        permissions=permissions or [],
        rate_limit=rate_limit,
        is_active=True
    )

    db.add(api_key_record)
    await db.commit()
    await db.refresh(api_key_record)

    return {
        "message": "API Key创建成功",
        "api_key": api_key,  # 只在创建时返回一次
        "id": api_key_record.id
    }


@router.delete("/api-keys/{key_id}")
async def revoke_api_key(
    key_id: int,
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    """吊销API Key"""
    result = await db.execute(select(APIKey).where(APIKey.id == key_id))
    api_key = result.scalar_one_or_none()

    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="API Key不存在"
        )

    api_key.is_active = False
    await db.commit()

    return {"message": "API Key已吊销"}
